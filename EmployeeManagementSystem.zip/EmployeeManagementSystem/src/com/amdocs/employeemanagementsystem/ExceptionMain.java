package com.amdocs.employeemanagementsystem;

public class ExceptionMain {

	public static void main(String[] args) {
		int result = div();
		System.out.println(result);
	}

	public static int div() {

		int a = 100;
		int b = 20;
		int c = 0;

		try {
			c = a / b; // JVM will create an ArithmeticException object & it will
			// throw it to the catch block
			return c;
		} catch (ArithmeticException ae) {
			System.out.println(ae);
		}

		finally {

			System.out.println("after the catch block");
		}
		return 0;

	}
}

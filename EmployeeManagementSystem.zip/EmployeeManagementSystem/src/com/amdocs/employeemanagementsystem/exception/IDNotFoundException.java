package com.amdocs.employeemanagementsystem.exception;

public class IDNotFoundException extends Exception {

	public IDNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
}

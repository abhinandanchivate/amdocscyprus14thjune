package com.amdocs.employeemanagementsystem;

import com.amdocs.employeemanagementsystem.exception.IDNotFoundException;
import com.amdocs.employeemanagementsystem.model.Employee;
import com.amdocs.employeemanagementsystem.service.EmployeeService;

public class Main {

	
	public static void main(String[] args) {
		System.out.println("Hello from Abhi");
	// System : Class
		// out : static ref.
		//println : method
		
		// to use addEmployee method from Employee service : 
		// do we need to create the object ?
		// how to create the object
		// ClassName referenceName = new Constructor();
		//                   ref Name        Object
		// references are responsible for refering the object location.
		EmployeeService employeeService= new EmployeeService();
		
		Employee employee = new Employee();
		employee.setEmpId("AB001");
		employee.setEmpFirstName("abhinandan");
		employee.setEmpLastName("chivate");
		employee.setEmpSalary(100.0f); // 100.0f => float literal (const)
		
		String result = employeeService.addEmployee(employee);
		
		if("success".equals(result)) {
			System.out.println("employee added successfully");
		}
		else {
			System.out.println("problem");
		}
		
		Employee[] employees = employeeService.getEmployees();
		
		// do we need to traverse the array?
		
		for (Employee employee2 : employees) {
			if(employee2!=null)
			System.out.println(employee2); // employee2.toString()
		}
		// IDNOTFOUNDException
		Employee employee2 = null;
		try {
			employee2 = employeeService.getEmployeeDetailsById("AB002");
		} catch (IDNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(employee2!=null) {
			System.out.println("employee exists");
		}
		else {
			System.out.println("not present");
		}
		
	}
}

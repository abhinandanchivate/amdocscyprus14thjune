package com.amdocs.employeemanagementsystem.service;

import com.amdocs.employeemanagementsystem.exception.IDNotFoundException;
import com.amdocs.employeemanagementsystem.model.Employee;

public class EmployeeService {

	private Employee [] employees = new Employee[5];

	private static int counter = 0;
	
	
	// add new employee
	public String addEmployee(Employee employee) {
		
		if(counter<5) {
			employees[counter] = employee;
			counter++;
			return "success";
		}
		else {
			return "nospace";
		}
		
		
	}
	// get single employee details based on ID
	public Employee getEmployeeDetailsById(String id) throws IDNotFoundException {
		// to return the specific record 
		// do we need to traverse the array?
		try {
		for (Employee employee : employees) {
			if(employee!=null) {
			if(employee.getEmpId().equals(id) ) {
				return employee;
			}}
		}
		throw new IDNotFoundException("Id is not available");
		}
		catch(IDNotFoundException ie) {
		throw ie;
			
		}
		
	}
	
	
	// get all Employee details
	
	public Employee[] getEmployees() {
		
		return employees;
	}
	
	// remove employee  ==> if employee id is not available then you should throw IDNOTfoundException
	// update employee details. ==> 
	
}

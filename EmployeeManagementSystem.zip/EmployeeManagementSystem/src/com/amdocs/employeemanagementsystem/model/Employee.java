package com.amdocs.employeemanagementsystem.model;

import lombok.Data;

@Data
public class Employee {

	
	private String empId; // to hold the emp id
	
	private String empFirstName; // to hold the emp first name 
	
	private String empLastName; // to hold last name
	
	private float empSalary; // to hold salary
	
	
	
	
}
